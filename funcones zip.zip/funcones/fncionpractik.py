def sumar (a, b):
        return a + b

print(f'resultado de la suma es : {sumar(4,6)}')

#argmentos variables 
def listarNombres(*nombres):
        for nombre in nombres:
                print(nombre)

listarNombres('tito', 'titopp', 'titodblep')

        