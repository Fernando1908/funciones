def repetir_texto(texto, veces):
    return texto * veces


texto = "hola "
veces = 3
resultado = repetir_texto(texto, veces)
print(resultado)  