def cambiar_caso(texto):
    return texto()


texto = "hola mundo"
resultado = cambiar_caso(texto)
print(resultado)  
