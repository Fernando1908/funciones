def millas_a_kilometros(millas):
    return millas * 1.60934


millas = 10
kilometros = millas_a_kilometros(millas)
print(f"{millas} millas son {kilometros:.2f} kilómetros")
