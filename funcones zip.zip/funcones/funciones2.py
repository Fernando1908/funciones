import math

def area_circulo(radio):
    return math.pi * radio ** 2


radio = 7
area = area_circulo(radio)
print(f"El área de un círculo con radio {radio} es {area:.2f}")
