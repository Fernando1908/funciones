
def calcular_temperatura_media(maxima, minima):
    return (maxima + minima) / 2


def programa_principal():
    
    numero_dias = int(input("¿Cuantos días vas a introducir? "))

    
    for dia in range(1, numero_dias + 1):
        print(f"\nDía {dia}:")
        maxima = float(input("Introduce la temperatura maxima: "))
        minima = float(input("Introduce la temperatura minima: "))
        
        
        media = calcular_temperatura_media(maxima, minima)
        
       
        print(f"La temperatura media del dia {dia} es {media:.2f} grados.")


programa_principal()
