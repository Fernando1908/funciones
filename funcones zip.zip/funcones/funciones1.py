def saludar(nombre):
    return f"Hola, {nombre}"


saludo = saludar("IKER")
print(saludo)  
